package lib

//
//func TestSendMail(t *testing.T) {
//
//	s := model.Message{
//		User: "postmaster@2bops.me",
//		Ssl:false,
//		ToUser: "ysb6931@closeli.cn",
//		Port: 25,
//		Host: "smtp.mailgun.org",
//		Password: "81ca75b97d3c68a4ae0a6266592b4f7e",
//
//	}
//
//	SendMail(s)
//}
//
//func TestSendDingMsg(t *testing.T) {
//
//	s := model.Message{
//		WebHook: "https://oapi.dingtalk.com/robot/send?access_token=215728067785e3b7a8ea0f99b188754f34ea53858b08067508f782ae1fdfab3f",
//	}
//	SendDingMsg(s,"")
//}