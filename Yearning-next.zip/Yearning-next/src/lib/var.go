package lib

const Version = "3.1.8.1 Uranus"
