package osc

// OscPercent show OSC percent
//func OscInfo(c yee.Context) (err error) {
//	var k = &OSC{WorkId: c.Params("work_id")}
//	return c.JSON(http.StatusOK, common.SuccessPayload(k.Percent()))
//	websocket.Handler(func(ws *websocket.Conn) {
//		defer ws.Close()
//		workId := c.QueryParam("work_id")
//		var msg string
//	}
//}

// OscKill will kill OSC command
//func OscKill(c yee.Context) (err error) {
//	var k = OSC{WorkId: c.Params("work_id")}
//	return c.JSON(http.StatusOK, common.SuccessPayLoadToMessage(k.Kill()))
//}
