---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: ''
assignees: ''

---

**Describe the Feature**
A clear and concise description of what you expected to happen.

**Your idea**
A clear and concise description of what the idea is.

**Screenshots**
If applicable, add screenshots to help explain your idea.